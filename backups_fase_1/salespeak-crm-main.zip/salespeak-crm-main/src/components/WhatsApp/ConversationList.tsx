import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search, Users, ArrowUp, ArrowDown, Layers, WifiOff } from 'lucide-react';
import { ConversationFilters, WhatsappConversation } from '@/hooks/whatsapp/useWhatsappConversations';
import { useGroupedConversations, GroupedConversation } from '@/hooks/whatsapp/useGroupedConversations';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import IniciarConversaDialog from './IniciarConversaDialog';

interface ConversationListProps {
  conversations: WhatsappConversation[];
  groupedConversations: GroupedConversation[];
  loading: boolean;
  filters: ConversationFilters;
  onFiltersChange: (filters: ConversationFilters) => void;
  selectedGroupKey?: string;
  onSelectGroup: (group: GroupedConversation) => void;
  instances: Array<{ id: string; nome: string; status?: string }>;
  sortOrder: 'asc' | 'desc';
  onSortOrderChange: (order: 'asc' | 'desc') => void;
  onConversationOpened?: (conversationId: string, instanceId: string) => void;
}

export default function ConversationList({
  conversations,
  groupedConversations,
  loading,
  filters,
  onFiltersChange,
  selectedGroupKey,
  onSelectGroup,
  instances,
  sortOrder,
  onSortOrderChange,
  onConversationOpened,
}: ConversationListProps) {
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
  };

  return (
    <TooltipProvider>
      <div className="flex flex-col h-full bg-white overflow-hidden">
        {/* Header */}
        <div className="bg-[#f0f2f5] px-4 py-3 border-b border-[#d1d7db] flex-shrink-0">
          <h2 className="text-[#111b21] font-semibold text-base">Conversas</h2>
        </div>

        {/* Search + New conversation button */}
        <div className="p-2 bg-white flex-shrink-0">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#54656f]" />
              <Input
                placeholder="Pesquisar ou começar uma nova conversa"
                value={filters.search}
                onChange={(e) => onFiltersChange({ ...filters, search: e.target.value })}
                className="pl-10 bg-[#f0f2f5] border-none rounded-lg text-sm text-[#111b21] placeholder:text-[#667781] focus-visible:ring-0"
              />
            </div>
            <IniciarConversaDialog 
              instances={instances} 
              onConversationOpened={onConversationOpened}
            />
          </div>
        </div>

        {/* Filters */}
        <div className="px-2 pb-2 flex gap-2 bg-white flex-shrink-0">
          <Select
            value={filters.assignment}
            onValueChange={(value: 'mine' | 'mine_and_new' | 'all') => onFiltersChange({ ...filters, assignment: value })}
          >
            <SelectTrigger className="flex-1 h-8 text-xs bg-[#f0f2f5] border-none text-[#54656f]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mine_and_new">Minhas + Novas</SelectItem>
              <SelectItem value="mine">Minhas</SelectItem>
              <SelectItem value="all">Todas</SelectItem>
            </SelectContent>
          </Select>
          <Select
            value={filters.status}
            onValueChange={(value: 'all' | 'active' | 'unread' | 'finished') => {
              onFiltersChange({ ...filters, status: value });
            }}
          >
            <SelectTrigger className="flex-1 h-8 text-xs bg-[#f0f2f5] border-none text-[#54656f]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              <SelectItem value="active">Ativas</SelectItem>
              <SelectItem value="unread">Não lidas</SelectItem>
              <SelectItem value="finished">Finalizadas</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 bg-[#f0f2f5] hover:bg-[#e9edef]"
            onClick={() => onSortOrderChange(sortOrder === 'desc' ? 'asc' : 'desc')}
            title={sortOrder === 'desc' ? 'Mais recentes primeiro' : 'Mais antigas primeiro'}
          >
            {sortOrder === 'desc' ? (
              <ArrowDown className="h-4 w-4 text-[#54656f]" />
            ) : (
              <ArrowUp className="h-4 w-4 text-[#54656f]" />
            )}
          </Button>
        </div>

        {instances.length > 1 && (
          <div className="px-2 pb-2 bg-white flex-shrink-0">
            <Select
              value={filters.instanceId || 'all'}
              onValueChange={(value) => onFiltersChange({ ...filters, instanceId: value === 'all' ? undefined : value })}
            >
              <SelectTrigger className="h-8 text-xs bg-[#f0f2f5] border-none text-[#54656f]">
                <SelectValue placeholder="Todas instâncias" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas instâncias</SelectItem>
                {instances.map((inst) => (
                  <SelectItem key={inst.id} value={inst.id}>
                    <span className="flex items-center gap-1.5">
                      {inst.nome}
                      {inst.status !== 'connected' && (
                        <WifiOff className="h-3 w-3 text-amber-500" />
                      )}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Conversations list */}
        <div className="flex-1 min-h-0 overflow-y-auto">
          {loading ? (
            <div className="p-4 text-center text-[#667781]">Carregando...</div>
          ) : groupedConversations.length === 0 ? (
            <div className="p-4 text-center text-[#667781]">
              Nenhuma conversa encontrada
            </div>
          ) : (
            <div>
              {groupedConversations.map((group) => {
                const hasMultipleInstances = group.instances.length > 1;
                const isSelected = group.groupKey === selectedGroupKey;
                const unreadCount = group.totalUnread || 0;
                
                return (
                  <div
                    key={group.groupKey}
                    onClick={() => onSelectGroup(group)}
                    className={cn(
                      'w-full px-3 py-3 flex gap-3 hover:bg-[#f5f6f6] transition-colors text-left border-b border-[#e9edef] cursor-pointer',
                      isSelected && 'bg-[#f0f2f5]',
                      unreadCount > 0 && !isSelected && 'bg-[#f0fdf4]'
                    )}
                  >
                    <Avatar className="h-12 w-12 flex-shrink-0">
                      <AvatarImage src={group.photoUrl || undefined} />
                      <AvatarFallback className="bg-[#dfe5e7] text-[#54656f]">
                        {group.isGroup ? (
                          <Users className="h-5 w-5" />
                        ) : (
                          getInitials(group.mainName || '?')
                        )}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0 py-0.5">
                      {/* Linha 1: Nome + Hora */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0 flex-1">
                          <span className={cn(
                            'text-[15px] text-[#111b21] truncate',
                            unreadCount > 0 ? 'font-semibold' : 'font-normal'
                          )}>
                            {group.mainName}
                          </span>
                          {hasMultipleInstances && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Badge 
                                  variant="secondary" 
                                  className="h-5 px-1.5 gap-0.5 bg-[#25d366]/10 text-[#25d366] border-0 flex-shrink-0"
                                >
                                  <Layers className="h-3 w-3" />
                                  <span className="text-[10px]">{group.instances.length}</span>
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent side="top" className="max-w-[200px]">
                                <p className="text-xs font-medium mb-1">Instâncias:</p>
                                {group.instances.map(inst => (
                                  <p key={inst.id} className="text-xs">{inst.nome}</p>
                                ))}
                              </TooltipContent>
                            </Tooltip>
                          )}
                        </div>
                        <span className={cn(
                          'text-xs whitespace-nowrap flex-shrink-0',
                          unreadCount > 0 ? 'text-[#25d366] font-medium' : 'text-[#667781]'
                        )}>
                          {formatDistanceToNow(new Date(group.lastMessageAt), {
                            addSuffix: false,
                            locale: ptBR,
                          })}
                        </span>
                      </div>
                      
                      {/* Linha 2: Preview + Badge */}
                      <div className="flex items-center gap-2 mt-0.5">
                        <p className={cn(
                          'text-sm truncate flex-1',
                          unreadCount > 0 ? 'text-[#111b21]' : 'text-[#667781]'
                        )}>
                          {group.lastMessagePreview || 'Sem mensagens'}
                        </p>
                        {unreadCount > 0 && (
                          <span className="inline-flex items-center justify-center bg-[#25d366] text-white text-[11px] font-bold rounded-full shrink-0" style={{ minWidth: '20px', height: '20px', padding: '0 5px' }}>
                            {unreadCount}
                          </span>
                        )}
                      </div>
                      
                      {/* Linha 3: Atendente + Instância */}
                      <div className="flex items-center gap-2 text-xs text-[#667781] truncate mt-0.5">
                        {group.assignedUser && (
                          <span>👤 {group.assignedUser.nome}</span>
                        )}
                        {/* Mostrar instância (principal) */}
                        {group.instances.length > 0 && (
                          <span className="flex items-center gap-0.5">
                            📱 {group.instances[0].nome}
                            {/* Indicador de desconectada */}
                            {group.instances.some(inst => (inst as any).status !== 'connected') && (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <WifiOff className="h-3 w-3 text-amber-500" />
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-xs">Instância desconectada</p>
                                </TooltipContent>
                              </Tooltip>
                            )}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </TooltipProvider>
  );
}
